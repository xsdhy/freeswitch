#!/bin/sh
autoreconf -i -f
