The Cepstral SDK for Windows should be placed in c:\dev\cepstral
ex. C:\dev\cepstral\sdk\include
This SDK can be obtained from http://cepstral.com/
If you want a prebuilt version you may download one from http://files.freeswitch.org/windows/installer/