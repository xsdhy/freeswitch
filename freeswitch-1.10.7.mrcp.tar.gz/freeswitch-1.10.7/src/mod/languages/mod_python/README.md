## WARNING: new default module is mod_python3

`freeswitch-mod-python` debian package is NOT going to be installed by default.
`freeswitch-mod-python3` will be installed instead.

You should remove `freeswitch-mod-python3` package and install `freeswitch-mod-python` manually if you want.
